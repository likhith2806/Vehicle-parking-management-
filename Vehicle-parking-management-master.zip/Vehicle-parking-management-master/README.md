# Vehicle-parking-management
A mini project on DBMS and web development
## Introduction
  The main objective of parking system is to manage the details of the customer, Duration, Parking fees and Vehicle type.
